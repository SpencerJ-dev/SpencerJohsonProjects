//
//  LoginViewController.swift
//  HawkChat2
//
//  Created by Spencer C. Johnson on 11/30/20.
//

import UIKit

class LoginViewController: UIViewController {

    let bloggerModel = BloggerModel.sharedInstance
    
    @IBOutlet weak var loginID: UITextField!
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var lognError: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    @IBAction func login(_ sender: UIButton) {
        bloggerModel.loginBlogger(withEmail: loginID.text!, withPassword: password.text!){
              valid in
            if valid {
                // we can segue to TabBarController if the login is valid
                self.performSegue(withIdentifier: "messagesSegue", sender: self)
            } else {
                print ("invalid user")
                DispatchQueue.main.async {
                    self.lognError.text = "Invalid Username/Password"
                }
            }
        }
       
    }
    
}
