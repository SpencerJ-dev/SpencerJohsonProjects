//
//  RegisterViewController.swift
//  HawkChat2
//
//  Created by Spencer C. Johnson on 11/30/20.
//

import UIKit

class RegisterViewController: UIViewController {
    
    // TO DO
    
    // setup outlets to UITextFields, UILabel
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func done(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func cancel(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
    // TO DO
    
    // Implement method(s) to handle registration info
    //  + Verify all the data fields have values
    //  + Password and Confirming Password match
    //  + Request to model is processed asynchronously
    //  + A message is displayed confirming or failure of registraiton
    

}
