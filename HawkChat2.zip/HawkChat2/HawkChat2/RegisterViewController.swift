//
//  RegisterViewController.swift
//  HawkChat2
//
//  Created by Spencer C. Johnson on 11/30/20.
//

import UIKit

class RegisterViewController: UIViewController {
    
    // TO DO
    
    // setup outlets to UITextFields, UILabel
    @IBOutlet weak var textFieldLoginEmail: UITextField!
    @IBOutlet weak var textFieldLoginPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func done(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func cancel(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func processRegister(_ sender: UIButton) {
        guard
            let email = textFieldLoginEmail.text,
            let password = textFieldLoginPassword.text,
            email.count > 0,
            password.count > 0
            else {
                return
        }
        let defaults = UserDefaults.standard
        let credentials:Dictionary<String, String> = ["userid" : email,
                                                      "password": password]


        defaults.set (credentials, forKey: self.userInfoKeyConstant)
        
        Auth.auth().signIn (withEmail: email, password: password) { user, error in
            if let error = error, user == nil {
                let alert = UIAlertController(title: "Sign In Failed",
                                              message: error.localizedDescription,
                                              preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                
                self.present(alert, animated: true, completion: nil)
            } else {
                
            }
            
        }
           // TO DO
    
    // Implement method(s) to handle registration info
    //  + Verify all the data fields have values
    //  + Password and Confirming Password match
    //  + Request to model is processed asynchronously
    //  + A message is displayed confirming or failure of registraiton
    

}
}
