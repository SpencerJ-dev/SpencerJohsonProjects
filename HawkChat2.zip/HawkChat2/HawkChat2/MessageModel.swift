//
//  MessageModel.swift
//  HawkChat2
//
//  Created by Spencer C. Johnson on 11/30/20.
//

import Foundation
import FirebaseDatabase

class MessageModel {
    
    static let sharedInstance = MessageModel()
    
    let messagesRef = Database.database().reference(withPath: "Messages")
    var listObserver: UInt?
    
    var postedMessages = [Message] ()
    
    private init() {
        
    }
    
    func postNewMessage (message msg: String, fromBlogger blogger: Blogger, postTime pt: Date) {
        let dtString = displayDateTime(dt: pt)
        let author = blogger.name
        let newMessage = Message(postTime: dtString, author: author, content: msg)
        print (newMessage)
        let msgKey = intDateTime(dt: pt)
        print (msgKey)
        let newMessageRef = messagesRef.child(msgKey)
        newMessageRef.setValue(newMessage.toAnyObject())
    }
    
    func listMessages (completionHandler: @escaping (_ result: Bool) -> ()) {
       
            listObserver = messagesRef.observe(.value, with: {snapshot in
                self.postedMessages.removeAll()
                for child in snapshot.children {
                    if let snapshot = child as? DataSnapshot, let aMessage = Message(snapshot: snapshot) {
                        self.postedMessages.append(aMessage)
                    }
                }
                self.postedMessages.reverse()
                completionHandler(true)
        })
    }
    
    func unSubscribe() {
        if let obs = listObserver {
            messagesRef.removeObserver(withHandle: obs)
        }
    }
    
    func intDateTime(dt: Date) -> String {
        let formatter1 = DateFormatter()
        formatter1.dateFormat = "yMMddHmssSSSS"
        return (formatter1.string(from: dt))
    }
    
    func displayDateTime (dt: Date) -> String {
        let formatter1 = DateFormatter()
        formatter1.dateFormat = "M/d/yy h:mm:ss a"
        return (formatter1.string(from: dt))
    }
    
}
