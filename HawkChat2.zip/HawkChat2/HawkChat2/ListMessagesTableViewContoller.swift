//
//  ListMessagesTableViewContoller.swift
//  HawkChat2
//
//  Created by Spencer C. Johnson on 11/30/20.
//

import UIKit

class ListMessagesTableViewController: UITableViewController {
    
    let bloggerModel = BloggerModel.sharedInstance
    let messagesModel = MessageModel.sharedInstance
    
    var blogMessages = [Message] ()
    
    @IBAction func logout(_ sender: UIBarButtonItem) {
        bloggerModel.signOutUser() {
            result in
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set the tableview row height to resize based on containted view in TableViewCell
        // we also need to given an estimated height, but it is adjusted by TVC
        
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 200
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // fetch messages from the model. provide the closure upon async call back
        
        messagesModel.listMessages() {
            result in
            if (result) {
                self.blogMessages.removeAll()
                self.blogMessages = self.messagesModel.postedMessages
                
                DispatchQueue.main.async {
                    self.tableView.reloadData() // note we need to do this in main queue
                                                //   as we are doing a UI update
                }
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // we need to unsubscribe from listening to messages from the model
        
        messagesModel.unSubscribe()
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return blogMessages.count
    }

     
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "messageCell", for: indexPath) as! MessageTableViewCell

        // Configure the cell...
        let thisMessage = blogMessages[indexPath.row]
        cell.messageAuthor.text = thisMessage.author + " " + thisMessage.postDateTime
        cell.message.text = thisMessage.content

        return cell
    }
    


}
