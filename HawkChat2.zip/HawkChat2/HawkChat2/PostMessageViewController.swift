//
//  PostMessageViewController.swift
//  HawkChat2
//
//  Created by Spencer C. Johnson on 11/30/20.
//

import UIKit

class PostMessageViewController: UIViewController {
    let messageModel = MessageModel.sharedInstance
    let bloggerModel = BloggerModel.sharedInstance
    
    @IBOutlet weak var newMessage: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func logout(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }

    
    @IBAction func SaveMessage (_sender: UIBarButtonItem) {
        newMessage.resignFirstResponder()
        let blogger = bloggerModel.loggedInBlogger!
        messageModel.postNewMessage(message: newMessage.text!, fromBlogger: blogger, postTime: Date())
    }

    @IBAction func clear(_ sender: UIBarButtonItem) {
        newMessage.text = ""
    }
}
