//
//  BloggerModel.swift
//  HawkChat2
//
//  Created by Spencer C. Johnson on 11/30/20.
//

import Foundation
import FirebaseAuth
import FirebaseDatabase

class BloggerModel {
    
    static let sharedInstance = BloggerModel ()
 
    
    var loggedInBlogger: Blogger?
    let bloggersDbRef = Database.database().reference(withPath: "Bloggers")
    
    
    private init() {
    }
    
    func registerBlogger(withEmail email: String, withPassword password: String, username name: String, completionHandler: @escaping (_ status: Bool) -> ()) {
        
        Auth.auth().createUser(withEmail: email, password: password) {
            result, error in
            if error == nil {
                self.addBlogger(userName: name, withEmail: email, key: (result?.user.uid)!)
                completionHandler(true)
                
            } else {
                print ("error: \(String(describing: error))")
                completionHandler(false)
            }
        }
        
    }
    
    func addBlogger (userName name: String, withEmail email: String, key: String)  {
        
        let ref = self.bloggersDbRef.child(key)
        let newBlogger = Blogger(uid: key, name: name, email: email)
        
        ref.setValue(newBlogger.toAnyObject())
    }
    
    func loginBlogger(withEmail email: String, withPassword password: String, completionHandler: @escaping (_ status: Bool) -> ()) {
        
        Auth.auth().signIn(withEmail: email, password: password) {
            result, error in
            if error == nil {
                print ("used signed into firebase")
                self.findUser(uid: (result?.user.uid)!) {
                    validUser in
                    if validUser {
                        completionHandler(true)
                    } else {
                        completionHandler(false)
                    }
                }
                
            } else {
                print ("error: \(String(describing: error))")
                completionHandler(false)
            }
        }
    }
    
    func findUser(uid: String, completionHandler: @escaping (_ validUser: Bool) -> ()) {
        let userRef = bloggersDbRef.child(uid)
        print ("find uid: \(uid)")
        userRef.observeSingleEvent(of: .value, with: {snapshot in
            if let aBlogger = Blogger (snapshot: snapshot) {
                self.loggedInBlogger = aBlogger
                completionHandler (true)
            } else {
                print ("can't find item")
                completionHandler(false)
            }
        })
    }
    
    func signOutUser (completionHandler: @escaping (_ status: Bool) -> ()) {
        do {
            
            if let _ = self.loggedInBlogger {
                try Auth.auth().signOut()
                self.loggedInBlogger = nil
                completionHandler(true)
            }
        }
        catch {
            print ("signout failed")
            completionHandler(false)
        }
        
    }
    
}
