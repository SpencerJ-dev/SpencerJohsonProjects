//
//  Message.swift
//  HawkChat2
//
//  Created by Spencer C. Johnson on 11/30/20.
//

import Foundation
import FirebaseDatabase

struct Message {
    let postDateTime: String
    let author: String
    let content: String
    let ref:DatabaseReference?
    
    // TO DO for extra credits
    
    //  Declare property var for handling how many like the blog post
    //  Declare property var to reference to the image associated with the blog
    //  Modify methods below to handle the added properties
    
    
    init (postTime: String, author: String, content: String) {
        self.postDateTime = postTime
        self.author = author
        self.content = content
        self.ref = nil
    }
    
    init?(snapshot: DataSnapshot) {
        guard
            let value = snapshot.value as? [String: AnyObject],
            let author = value["author"] as? String,
            let content = value["content"] as? String,
            let postDateTime = value ["postDateTime"] as? String else {
            return nil
        }
        
        self.ref = snapshot.ref
        self.author = author
        self.content = content
        self.postDateTime = postDateTime
        
    }
    
    func toAnyObject() -> Any {
        return [
            "author": author,
            "content": content,
            "postDateTime": postDateTime
        ]
    }
    
}
