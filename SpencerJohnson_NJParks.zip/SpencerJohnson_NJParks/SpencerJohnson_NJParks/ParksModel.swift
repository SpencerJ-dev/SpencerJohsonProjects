//
//  ParksModel.swift
//  SpencerJohnson_NJParks
//
//  Created by Spencer C. Johnson on 10/15/20.
//

import Foundation

struct ParkInfo:Codable
{
    var comments:String
    var objNum:Int
    var park_: Int
    var parkId: Int
    var parkName: String
    var type: String
    var township: String
    var county: String
        
    enum CodingKeys: String, CodingKey {
        case comments = "COMMENTS"
        case objNum = "OBJECTID"
        case park_ = "PARK_"
        case parkId = "PARK_ID"
        case parkName = "NAME"
        case type = "TYPE"
        case township = "TOWNSHIP"
        case county = "COUNTY"
        
    }
}


class ParksModel {
    var parkInfo:[ParkInfo] = []
    

    static let sharedInstance = ParksModel()
  
    
    private init () {
        readParkData()
        print (parkInfo.count)
    }
    
    func getPark() -> [ParkInfo] {
        return parkInfo
    }
    
    
    func removePark (objectId: Int) {
        if let objectIndex = parkInfo.firstIndex(where: {$0.objNum == objectId}) {
            parkInfo.remove(at: objectIndex)
        }
    }
    
    // update the gas pump comments
    func updateComments (forParkInfoID parkinfoID: Int, comments comment: String) {
        if let objectIndex = parkInfo.firstIndex(where: {$0.objNum == parkinfoID}) {
            parkInfo[objectIndex].comments = comment
        }
    }
    
    func readParkData() {
        
        if let filename = Bundle.main.path(forResource: "njparks", ofType: "json") {
            do {
                let jsonStr = try String(contentsOfFile: filename)
                let jsonData = jsonStr.data(using: .utf8)!
                parkInfo = try! JSONDecoder().decode([ParkInfo].self, from:jsonData)
            } catch {
                print("The file could not be loaded")
            }
        }
      
    }
}
