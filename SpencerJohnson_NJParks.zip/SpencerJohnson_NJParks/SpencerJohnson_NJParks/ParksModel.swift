//
//  ParksModel.swift
//  SpencerJohnson_NJParks
//
//  Created by Spencer C. Johnson on 10/15/20.
//

import Foundation
struct ParkInfo:Codable
{
    var comments:String
    var longitude:Double
    var latitude:Double
    var objNum:Int
    var park_: Int
    var parkId: Int
    var parkName: String
    var type: String
    var township: String
    var county: String
    var r: Int
    var X_Coord: Double
    var Y_Coord: Double
    var polygonID: Int
    var scale: Int
    var angle: Int
    var status: String
    
    enum CodingKeys: String, CodingKey {
        case comments = "COMMENTS"
        case longitude = "LONGITUDE"
        case latitude = "LATITUDE"
        case objNum = "OBJECTID"
        case park_ = "PARK_"
        case parkId = "PARK_ID"
        case parkName = "NAME"
        case type = "TYPE"
        case township = "TOWNSHIP"
        case county = "COUNT"
        case r = "R"
        case X_Coord = "X_COORD"
        case Y_Coord = "Y_COORD"
        case polygonID = "POLYGONID"
        case scale = "SCALE"
        case angle = "ANGLE"
        case status = "STATUS"
    }
}


class ParksModel {
    var parkInfo:[ParkInfo] = []
    

    static let sharedInstance = ParksModel()
  
    
    private init () {
        readParkData()
        print (parkInfo.count)
    }
    
    func getPark() -> [ParkInfo] {
        return parkInfo
    }
    
    
    func removePark (objectId: Int) {
        if let objectIndex = parkInfo.firstIndex(where: {$0.objNum == objectId}) {
            parkInfo.remove(at: objectIndex)
        }
    }
    
    // update the gas pump comments
    func comments (forParkInfoID parkinfoID: Int, comments comment: String) {
        if let objectIndex = parkInfo.firstIndex(where: {$0.objNum == parkinfoID}) {
            parkInfo[objectIndex].comments = comment
        }
    }
    
    func readParkData() {
        
        if let filename = Bundle.main.path(forResource: "njparks", ofType: "json") {
            do {
                let jsonStr = try String(contentsOfFile: filename)
                let jsonData = jsonStr.data(using: .utf8)!
                parkInfo = try! JSONDecoder().decode([ParkInfo].self, from: jsonData)
            } catch {
                print("The file could not be loaded")
            }
        }
      
    }
}
