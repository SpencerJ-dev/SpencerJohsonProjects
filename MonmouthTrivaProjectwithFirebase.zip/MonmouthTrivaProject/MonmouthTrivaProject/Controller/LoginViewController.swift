//
//  LoginViewController.swift
//  MonmouthTrivaProject
//
//  Created by Spencer C. Johnson on 12/5/20.
//

import UIKit

class LoginViewController: UIViewController {

    let playerModel = PlayerModel.sharedInstance
    
    @IBOutlet weak var loginID: UITextField!
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var lognError: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func login(_ sender: UIButton) {
        pLayerModel.loginPlayers(withEmail: loginID.text!, withPassword: password.text!){
              valid in
            if valid {
                self.performSegue(withIdentifier: "quizHomeSegue", sender: self)
            } else {
                print ("invalid user")
                DispatchQueue.main.async {
                    self.lognError.text = "Invalid Username/Password"
                }
            }
        }
       
    }
    
}
