//
//  PlayerModel.swift
//  MonmouthTrivaProject
//
//  Created by Spencer C. Johnson on 12/3/20.
//

import Foundation
import FirebaseAuth
import FirebaseDatabase

class PlayerModel {
    
    static let sharedInstance = PlayerModel ()
 
    
    var loggedInPlayer: Player?
    let playersDbRef = Database.database().reference(withPath: "Players")
    
    
    private init() {
    }
    
    func registerPlayer(withEmail email: String, withPassword password: String, username name: String, completionHandler: @escaping (_ status: Bool) -> ()) {
        
        Auth.auth().createUser(withEmail: email, password: password) {
            result, error in
            if error == nil {
                self.addPlayer(userName: name, withEmail: email, key: (result?.user.uid)!)
                completionHandler(true)
                
            } else {
                print ("error: \(String(describing: error))")
                completionHandler(false)
            }
        }
        
    }
    
    func addPlayer (userName name: String, withEmail email: String, key: String)  {
        
        let ref = self.playersDbRef.child(key)
        let newPlayer = Player(uid: key, name: name, email: email, highScore: <#Int#>)
        ref.setValue(newPlayer.toAnyObject())
    }
    
    func loginPlayers(withEmail email: String, withPassword password: String, completionHandler: @escaping (_ status: Bool) -> ()) {
        
        Auth.auth().signIn(withEmail: email, password: password) {
            result, error in
            if error == nil {
                print ("used signed into firebase")
                self.findUser(uid: (result?.user.uid)!) {
                    validUser in
                    if validUser {
                        completionHandler(true)
                    } else {
                        completionHandler(false)
                    }
                }
                
            } else {
                print ("error: \(String(describing: error))")
                completionHandler(false)
            }
        }
    }
    
    func findUser(uid: String, completionHandler: @escaping (_ validUser: Bool) -> ()) {
        let userRef = playersDbRef.child(uid)
        print ("find uid: \(uid)")
        userRef.observeSingleEvent(of: .value, with: {snapshot in
            if let aPlayer = Player (snapshot: snapshot) {
                self.loggedInPlayer = aPlayer
                completionHandler (true)
            } else {
                print ("can't find item")
                completionHandler(false)
            }
        })
    }
    
    func signOutUser (completionHandler: @escaping (_ status: Bool) -> ()) {
        do {
            
            if let _ = self.loggedInPlayer {
                try Auth.auth().signOut()
                self.loggedInPlayer = nil
                completionHandler(true)
            }
        }
        catch {
            print ("signout failed")
            completionHandler(false)
        }
        
    }
    
}
