//
//  ParkAnnotation.swift
//  NJSchoolsMap
//
//  Created by Spencer C. Johnson on 11/14/20.
//

import Foundation
import MapKit
import Contacts


class PumpAnnotation: NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    
    init (_ latitude: CLLocationDegrees, longitude: CLLocationDegrees, title: String, subTitle: String) {
        self.coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        self.title = title
        self.subtitle = subTitle
    }
    
    func mapItem() -> MKMapItem {
        let destinationTitle = title! + ", " + subtitle!
        let addrDict = [CNPostalAddressCityKey: destinationTitle]
        let placemark = MKPlacemark (coordinate: coordinate, addressDictionary: addrDict)
        let mapItem = MKMapItem (placemark: placemark)
        return mapItem
        
    }
    
}
