//
//  MapViewController.swift
//  NJSchoolsMap
//
//  Created by Spencer C. Johnson on 11/14/20.
//

import UIKit
import CoreLocation
import MapKit

class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var myMapView: MKMapView!
    
    let locationManager = CLLocationManager()
    var currentLocation:CLLocation!
    
    let NJParkModel = ParkModel.sharedInstance
    var NJParks: [ParkInfo] = []
    var parkAnnotation:[ParkAnnotation] = []
    let region = 8000.00
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        locationManager.requestWhenInUseAuthorization()
        
        myMapView.showsUserLocation = true
        myMapView.delegate = self
    
        NJParks = NJParkModel.parkInfo
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        centerMapToLocation()
        // addOneLocation()
        
        addPark()
    }
    
    func centerMapToLocation() {
        let greatHall =  CLLocation (latitude: 40.28010, longitude: -74.00476)
        let greatHall2D = CLLocationCoordinate2D (latitude: greatHall.coordinate.latitude, longitude: greatHall.coordinate.longitude)
        let coordinateRegion = MKCoordinateRegion(center: greatHall2D, latitudinalMeters: region, longitudinalMeters: region)
        myMapView.setRegion(coordinateRegion, animated: true)
        
    }
    
    func addPark() {
        for park in NJParks {
            let annotation = ParkAnnotation(park.latitude, longitude: park.longitude, title: park.parkName, subTitle: park.county)
                parkAnnotation.append(annotation)
        }
        myMapView.addAnnotations(parkAnnotation)
    }
    
    func addOneLocation ()  {
        
        let annotation = MKPointAnnotation()
        let greatHall =  CLLocation (latitude: 40.28010, longitude: -74.00476)
        annotation.coordinate = CLLocationCoordinate2D(latitude: greatHall.coordinate.latitude, longitude: greatHall.coordinate.longitude)
        annotation.title = "The Great Hall at Shadow Lawn"
        annotation.subtitle = "West Long Branch, NJ"
        
        myMapView.addAnnotation(annotation)
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        var annotationView = MKMarkerAnnotationView()
        
        let identifier = "park"
        
        guard annotation is ParkAnnotation else {return nil}
        
        annotationView.clusteringIdentifier = nil
        if let dequedAnnotation = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKMarkerAnnotationView {
            annotationView = dequedAnnotation
        } else {
            annotationView.markerTintColor = UIColor.blue
            annotationView.animatesWhenAdded = true
            annotationView.glyphImage = UIImage(named:"smallParkIcon.png")
            
            // setup calloutviews if needed
            
            annotationView.canShowCallout = true
            annotationView.calloutOffset = CGPoint(x: -5.0, y: 5.0)
            
            // create a mapButton - a frame, a background image. add the button as rightCalloutAccessory
            
            let mapButton = UIButton (frame: CGRect(origin: CGPoint.zero, size: CGSize(width: 50.0, height: 60.0)))
            mapButton.setBackgroundImage(UIImage(named: "ios-map-icon-12.png"), for: UIControl.State())
            annotationView.rightCalloutAccessoryView = mapButton
        }
        
        
        return annotationView
    }

    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        currentLocation = userLocation.location
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        let thisLocation = view.annotation as! ParkAnnotation
        if view.rightCalloutAccessoryView == control {
            let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
            // invoke the Apple Maps application with current locations coordinate and address set as MKMapItem
            thisLocation.mapItem().openInMaps(launchOptions: launchOptions)
        }
    }
    
    @IBAction func selectMapType(_ sender: UISegmentedControl) {
        switch (sender.selectedSegmentIndex) {
        case 0:
            myMapView.mapType = .standard
        case 1:
            myMapView.mapType = .satellite
        case 2:
            myMapView.mapType = .hybridFlyover
        default:
            myMapView.mapType = .standard
        }
    }
}

