//
//  ParksDetailViewController.swift
//  NJSchoolsMap
//
//  Created by Spencer C. Johnson on 11/14/20.
//
import UIKit

class ParkDetailViewController: UIViewController {
    
    var thisNJPark: ParkInfo?
    
    let myNJParkModel = ParksModel.sharedInstance

    @IBOutlet weak var comment: UITextField!
    @IBOutlet weak var parkName: UILabel!
    @IBOutlet weak var parkTownship: UILabel!
    @IBOutlet weak var parkCounty: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        print (thisNJPark!)
       
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        comment.text = thisNJPark?.comments
        parkName.text = thisNJPark?.parkName
        parkCounty.text = thisNJPark?.county
        parkTownship.text = thisNJPark?.township
        
    }

    @IBAction func saveComment(_ sender: Any) {
        myNJParkModel.updateComments(forParkInfoID: thisNJPark!.objNum, comments: comment.text!)
    }
    @IBAction func customBack(_ sender: Any) {
       _ = self.navigationController?.popToRootViewController(animated: true)
    }    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
