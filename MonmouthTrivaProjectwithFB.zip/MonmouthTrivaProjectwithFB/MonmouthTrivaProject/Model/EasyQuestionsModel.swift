//
//  EasyQuestionsModel.swift
//  MonmouthTrivaProject
//
//  Created by Spencer C. Johnson on 12/5/20.
//

import Foundation

struct EasyQuestions: Codable{
    var image: String?
    var qnum: Int?
    var qtext: String?
    var OptionA: String?
    var OptionB: String?
    var OptionC: String?
    var OptionD: String?
    var answer: Int?
    
    enum CodingKeys: String, CodingKey {
        case image = "Image"
        case qnum = "Num"
        case qtext = "Question"
        case OptionA = "A"
        case OptionB = "B"
        case OptionC = "C"
        case OptionD = "D"
        case answer = "Answer"
    }
}

class EasyQuestionsModel {
    var easyquestions:[EasyQuestions] = []
    
   
    static let sharedInstance = EasyQuestionsModel()
    // constructor
    
    private init () {
        readQuestionsData()
        print (easyquestions.count)
    }
    
    func getQuestions() -> [EasyQuestions] {
        return easyquestions
    }
    
    func readQuestionsData() {
        
        if let filename = Bundle.main.path(forResource: "EasyQuestions", ofType: "json") {
            do {
                let jsonStr = try String(contentsOfFile: filename)
                let jsonData = jsonStr.data(using: .utf8)!
                easyquestions = try! JSONDecoder().decode([EasyQuestions].self, from: jsonData)
            } catch {
                print("The file could not be loaded")
            }
        }
      
    }
}
