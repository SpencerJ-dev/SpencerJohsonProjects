//
//  Player.swift
//  MonmouthTrivaProject
//
//  Created by Spencer C. Johnson on 12/11/20.
//

import Foundation
import FirebaseDatabase

struct Player {
    
    let uid: String
    let email: String
    let name: String
    let ref: DatabaseReference?
    let userKey: String
    var highScore = 0
    
    // constructor when created from user interface
    
    init (uid: String, name: String, email: String, highScore: Int ){
        self.ref = nil
        self.userKey = uid
        self.uid = uid
        self.name = name
        self.email = email
        self.highScore = highScore
    }
    
    // constructor when created from a snapshot of Database
    
    init?(snapshot: DataSnapshot) {
        guard
            let value = snapshot.value as? [String: AnyObject],
            let name = value["name"] as? String,
            let email = value["email"] as? String else {
            return nil
        }
        
        self.ref = snapshot.ref
        self.userKey = snapshot.key
        self.name = name
        self.email = email
        self.uid = snapshot.key
    }
    
    func toAnyObject() -> Any {
        return [
            "name": name,
            "email": email
        ]
    }
}

