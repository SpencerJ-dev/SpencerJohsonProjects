//
//  RegisterViewController.swift
//  MonmouthTrivaProject
//
//  Created by Spencer C. Johnson on 12/5/20.
//

import Foundation
import UIKit
import Firebase

class RegisterViewController: UIViewController {
    
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var confirmpassword: UITextField!
    @IBOutlet weak var username: UITextField!

    let playerModel = PlayerModel.sharedInstance
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func cancel(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func done(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func register(_ sender: UIButton) {
        if ((password.text?.elementsEqual(confirmpassword.text!)) != true) || ((confirmpassword.text?.elementsEqual(password.text!)) != true) {
            print("Passwords do not match, registration failed")
            
            let alert = UIAlertController(title: "ERROR", message: "Passwords do not match, please try again", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true, completion: nil)
            
            } else {
            playerModel.registerPlayer(withEmail: email.text!, withPassword: password.text!, username: username.text!) { [self]
                    result in
                if result {
                    print("Registered Player")
                    let alert = UIAlertController(title: "REGISTERED", message: "You are successfully registered", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default))
                    self.present(alert, animated: true, completion: nil)
                    if let uid = self.playerModel.loggedInPlayer?.uid {
                        print("uid: \(uid)")
                }
            }
        }
    }
        performSegue(withIdentifier: "HomeQuiz", sender: self) }
}

