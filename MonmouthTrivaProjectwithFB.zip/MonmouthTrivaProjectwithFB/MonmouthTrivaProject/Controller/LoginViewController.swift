//
//  LoginViewController.swift
//  MonmouthTrivaProject
//
//  Created by Spencer C. Johnson on 12/5/20.
//

import UIKit
import Firebase
import FirebaseAuth

class LoginViewController: UIViewController {

    let playerModel = PlayerModel.sharedInstance
    
    @IBOutlet weak var loginID: UITextField!
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var loginError: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func login(_ sender: UIButton) {
        playerModel.loginPlayers(withEmail: loginID.text!, withPassword: password.text!){
              valid in
            if valid {
                self.performSegue(withIdentifier: "quizHome", sender: self)
            } else {
                print ("invalid user")
                DispatchQueue.main.async {
                    self.loginError.text = "Invalid Username/Password"
                }
            }
        }
       
    }
    @IBAction func goRegister(sender:UIButton){
        performSegue(withIdentifier: "register", sender: self)
        }
}
