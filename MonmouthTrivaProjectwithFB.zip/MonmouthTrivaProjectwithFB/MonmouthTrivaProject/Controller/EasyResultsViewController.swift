//
//  EasyResultsViewController.swift
//  MonmouthTrivaProject
//
//  Created by Spencer C. Johnson on 12/10/20.
//

import UIKit

class EasyResultsViewController: UIViewController {
    var EQAViewController: EasyResultsViewController = EasyResultsViewController(nibName: nil, bundle: nil)
    var gamescore = EQAViewController.right
    
    @IBOutlet weak var gameMessage: UILabel!
    @IBOutlet weak var score: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
