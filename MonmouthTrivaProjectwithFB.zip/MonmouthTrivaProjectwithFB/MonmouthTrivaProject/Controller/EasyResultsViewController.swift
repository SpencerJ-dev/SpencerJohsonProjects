//
//  EasyResultsViewController.swift
//  MonmouthTrivaProject
//
//  Created by Spencer C. Johnson on 12/10/20.
//

import UIKit

class EasyResultsViewController: UIViewController {
   
    var gamescore = 0
    
    @IBOutlet weak var gameMessage: UILabel!
    @IBOutlet weak var score: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadResults()
        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "result"{
            let destinationController = segue.destination as! EQAViewController
            destinationController.right = gamescore
        }
    }
    func loadResults(){
        score.text = "\(gamescore)"
        if gamescore <= 2 {
            self.gameMessage.text = "Dont worry, you will do better next time!"
        }
        else if gamescore <= 4 {
            self.gameMessage.text = "Nice job but there's still room for improvement!"
        }
        else{
            self.gameMessage.text = "Excellent Job, you scored really high!"
        }
    }
    
    
}

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


