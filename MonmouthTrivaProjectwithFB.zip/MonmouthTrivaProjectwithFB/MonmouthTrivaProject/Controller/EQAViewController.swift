//
//  EQAViewController.swift
//  MonmouthTrivaProject
//
//  Created by Spencer C. Johnson on 12/5/20.
//

import UIKit
import Firebase

class EQAViewController: UIViewController {
    @IBOutlet weak var correct: UILabel!
    @IBOutlet weak var QImage: UIImageView!
    @IBOutlet weak var QText: UILabel!
    
    //button outley
    @IBOutlet weak var O_A: UIButton!
    @IBOutlet weak var O_B: UIButton!
    @IBOutlet weak var O_C: UIButton!
    @IBOutlet weak var O_D: UIButton!
    
    let myEQuestionModel = EasyQuestionsModel.sharedInstance

    var theseQuestions: [EasyQuestions] = []
    //var thisEasyQuestion: EasyQuestions?
    
    var questionNumber: Int = 0
    var right: Int = 0
    var notRight: Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        theseQuestions = myEQuestionModel.easyquestions
        loadQuestion()
        // Do any additional setup after loading the view.
    }
    //all 4 answer buttons connected to this method
    @IBAction func answerPressed(_ sender: UIButton) {
        if sender.tag == theseQuestions[questionNumber].answer {
            sender.backgroundColor = UIColor.green
            right += 1
            correct.text = "\(right)"
            O_A.isEnabled = false
            O_B.isEnabled = false
            O_C.isEnabled = false
            O_D.isEnabled = false
        }else{
            sender.backgroundColor = UIColor.red
            notRight+=1
            O_A.isEnabled = false
            O_B.isEnabled = false
            O_C.isEnabled = false
            O_D.isEnabled = false
        }
        questionNumber += 1
    }
    // the next button that moves you to the next view when the q array is done
    @IBAction func loadQuestion(){
        if questionNumber <= theseQuestions.count - 1{
            let thisQ = theseQuestions[questionNumber]
            O_A.isEnabled = true
            O_B.isEnabled = true
            O_C.isEnabled = true
            O_D.isEnabled = true
            O_A.backgroundColor = UIColor.white
            O_B.backgroundColor = UIColor.white
            O_C.backgroundColor = UIColor.white
            O_D.backgroundColor = UIColor.white
            QImage.image = UIImage(named:(thisQ.image!))
            QText.text = thisQ.qtext
            O_A.setTitle(thisQ.OptionA, for: UIControl.State.normal)
            O_B.setTitle(thisQ.OptionB, for: UIControl.State.normal)
            O_C.setTitle(thisQ.OptionC, for: UIControl.State.normal)
            O_D.setTitle(thisQ.OptionD, for: UIControl.State.normal)
        
        }else {
            performSegue(withIdentifier: "result", sender: self)
        }
            /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
}
