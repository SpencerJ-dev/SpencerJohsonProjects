//
//  EQAViewController.swift
//  MonmouthTrivaProject
//
//  Created by Spencer C. Johnson on 12/5/20.
//

import UIKit

class EQAViewController: UIViewController {
    
    var correct: Int
    var wrong: Int
    var thisEasyQuestion: EasyQuestions?
    
    let myEQuestionModel = EasyQuestionsModel.sharedInstance
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(thisEasyQuestion!)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
