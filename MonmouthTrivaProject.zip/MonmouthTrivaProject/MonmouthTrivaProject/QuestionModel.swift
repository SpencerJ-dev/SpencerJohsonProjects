//
//  QuestionModel.swift
//  MonmouthTrivaProject
//
//  Created by Spencer C. Johnson on 12/3/20.
//

import Foundation

struct Question:Codable{
    var image: String
    var qnum: Int
    var qtext: String
    var option: [String]
    var correctAnswer:Int
    var wrongAnswer: Int
    var isAnswered: Bool
    var isGameComplete: Bool
    
    enum CodingKeys: String, CodingKey {
        case image = "Image"
        case qnum = "Num"
        case qtext = "Question"
        case option = "Options"
    }
}

