//
//  PlayerModel.swift
//  MonmouthTrivaProject
//
//  Created by Spencer C. Johnson on 12/3/20.
//

import Foundation
