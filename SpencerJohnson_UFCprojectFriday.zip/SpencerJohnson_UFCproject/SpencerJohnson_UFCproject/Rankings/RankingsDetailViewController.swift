//
//  RankingsDetailViewController.swift
//  SpencerJohnson_UFCproject
//
//  Created by Spencer C. Johnson on 10/30/20.
//

import UIKit

class RankingsDetailViewController: UIViewController {
    var thisFighter: FighterInfo?
    
    let myFighterModel = TopUFCFighters.sharedInstance

    @IBOutlet weak var fighterPhoto: UIImage!
    @IBOutlet weak var fighterName: UILabel!
    @IBOutlet weak var fighterCountry: UILabel!
    @IBOutlet weak var fighterWins: UILabel!
    @IBOutlet weak var fighterLoses: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print (thisFighter!)
       
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        fighterName.text = thisFighter?.name
        fighterCountry.text = thisFighter?.from
        fighterWins.text = thisFighter?.wins
        fighterLoses.text = thisFighter?.loses
        
    }
    @IBAction func customBack(_ sender: Any) {
       _ = self.navigationController?.popToRootViewController(animated: true)
    }
}
