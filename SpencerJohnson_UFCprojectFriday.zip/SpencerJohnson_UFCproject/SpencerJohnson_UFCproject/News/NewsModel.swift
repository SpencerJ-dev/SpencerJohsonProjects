//
//  NewsModel.swift
//  SpencerJohnson_UFCproject
//
//  Created by Spencer C. Johnson on 10/30/20.
//

import Foundation
