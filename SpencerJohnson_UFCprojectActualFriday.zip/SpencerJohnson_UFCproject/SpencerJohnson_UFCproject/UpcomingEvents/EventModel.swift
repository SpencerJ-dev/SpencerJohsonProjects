//
//  EventModel.swift
//  SpencerJohnson_UFCproject
//
//  Created by Spencer C. Johnson on 10/29/20.
//

import Foundation
class EventModel {
    
    static let sharedInstance = EventModel()
    
    let photos = ["UFCFightNight.png": "UFCFightNight1.png",
               "UFCFightNight.png": "UFCFightNight2.png",
               "UFC-logo.png": "UFClogo1.png",]
    
    let date = ["Sat, Oct 31", "Sat, Nov 7", "Sat Nov 21"]

    var thumbNailPhotos:[String] = []
    
    private init() {
        thumbNailPhotos = Array(photos.keys)
        print (thumbNailPhotos)
    }

}
