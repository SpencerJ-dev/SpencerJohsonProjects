//
//  NewsCollectionViewCell.swift
//  SpencerJohnson_UFCproject
//
//  Created by Spencer C. Johnson on 10/31/20.
//

import UIKit

class NewsCollectionViewCell: UICollectionViewCell {
    
}
