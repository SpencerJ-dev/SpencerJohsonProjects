//
//  NewsModel.swift
//  SpencerJohnson_UFCproject
//
//  Created by Spencer C. Johnson on 10/30/20.
//

import Foundation
struct NewsInfo:Codable
{
        var title: String
        var author: String
        var date: String
        var summary: String
        var type: String
        var num: Int
        
        enum CodingKeys: String, CodingKey {
            case title = "Title"
            case author = "Author"
            case date = "Date"
            case summary = "Summary"
            case type = "Type"
            case num = "Num"
        }
}
class NewsModel{
    var newsInfo:[NewsInfo] = []
    static let sharedInstance = NewsModel()
  
    private init () {
        print (newsInfo.count)
    }
    
    func getNews() -> [NewsInfo] {
        return newsInfo
    }
    
    func removeNews (nums: Int) {
        if let objectIndex = newsInfo.firstIndex(where: {$0.num == nums}) {
            newsInfo.remove(at: objectIndex)
        }
    }
    
    func readPumpsData() {
        
        if let filename = Bundle.main.path(forResource: "UFCNews", ofType: "json") {
            do {
                let jsonStr = try String(contentsOfFile: filename)
                let jsonData = jsonStr.data(using: .utf8)!
                newsInfo = try! JSONDecoder().decode([NewsInfo].self, from: jsonData)
            } catch {
                print("The file could not be loaded")
            }
        }
    }
}


