//
//  TopUFCFighters.swift
//  SpencerJohnson_UFCproject
//
//  Created by Spencer C. Johnson on 10/29/20.
//

import Foundation

struct FighterInfo:Codable
{
        var name: String
        var from: String
        var photo: String
        var wins: String
        var loses: String
        var rank: Int
        
        enum CodingKeys: String, CodingKey {
            case name = "Name"
            case from = "From"
            case photo = "Photo"
            case wins = "Wins"
            case loses = "Loses"
            case rank = "Rank"
        }
    
}
    class TopUFCFighters {
        var fighterInfo:[FighterInfo] = []
        static let sharedInstance = TopUFCFighters()
      
        private init () {
            print (fighterInfo.count)
        }
        
        func getFighter() -> [FighterInfo] {
            return fighterInfo
        }
        
        func removeFighter (ranks: Int) {
            if let objectIndex = fighterInfo.firstIndex(where: {$0.rank == ranks}) {
                fighterInfo.remove(at: objectIndex)
            }
        }
        
        func readPumpsData() {
            
            if let filename = Bundle.main.path(forResource: "TopFighter", ofType: "json") {
                do {
                    let jsonStr = try String(contentsOfFile: filename)
                    let jsonData = jsonStr.data(using: .utf8)!
                    fighterInfo = try! JSONDecoder().decode([FighterInfo].self, from: jsonData)
                } catch {
                    print("The file could not be loaded")
                }
            }
        }
    }


